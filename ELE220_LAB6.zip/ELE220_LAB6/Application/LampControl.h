#ifndef __LAMPCONTROL_H
#define __LAMPCONTROL_H

#include <stdbool.h>
#include <stdint.h>
#include "cmsis_os.h"

bool LampControlInit(int maxLampsOn);

#endif // __LAMPCONTROL_H
