#include "main.h"
#include "my_printf.h"
#include "core_cm4.h"

void MyHardFault_Handler(void) {
    uint32_t countdown = 5;

    Myprintf("HardFault encountered! System will reset soon.\r\n");

    do {
        HAL_GPIO_TogglePin(RED_LED_GPIO_Port, RED_LED_Pin);
        Myprintf("In HardFault handler, system resetting in %d...\r\n", countdown);

        // Enkel forsinkelse, skape pause mellom led blinking og melding
        for (volatile uint32_t delay = 0; delay < 10000000; delay++);

        countdown--;
    } while (countdown > 0);

    NVIC_SystemReset();
}
