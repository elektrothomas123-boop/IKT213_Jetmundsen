#ifndef MY_APP_H_
#define MY_APP_H_

void MyApp(void);

#endif /* MY_APP_H_ */
