#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "cmsis_os.h"
#include "usart.h"
#include "my_printf.h"

#define MY_PRINTF_BUFF_SIZE 128

// Deklarer minnepool og meldingskø
osMemoryPoolId_t myPrintfPool;
osMessageQueueId_t myPrintfQueue;

// Tråd-ID for MyPrintfServer
osThreadId_t myPrintfServerHandle;

// Struktur for å holde meldinger
typedef struct {
    char buffer[MY_PRINTF_BUFF_SIZE];
} MyPrintfMessage;

void MyPrintf(const char *fmt, ...) {
    MyPrintfMessage *msg = osMemoryPoolAlloc(myPrintfPool, 0);  // Alloker minne fra pool
    if (msg == NULL) {
        // Håndter feil ved minneallokering
        return;
    }

    // Formater meldingen
    va_list args;
    va_start(args, fmt);
    vsnprintf(msg->buffer, sizeof(msg->buffer), fmt, args);
    va_end(args);

    // Send den formaterte meldingen til servertråden via meldingskø
    if (osMessageQueuePut(myPrintfQueue, &msg, 0, 0) != osOK) {
        // Hvis meldingen ikke kunne legges i køen, frigjør minnet
        osMemoryPoolFree(myPrintfPool, msg);
    }
}

void MyPrintfServer(void *arg) {
    MyPrintfMessage *receivedMsg;

    for (;;) {
        // Vent på meldinger fra meldingskøen
        if (osMessageQueueGet(myPrintfQueue, &receivedMsg, NULL, osWaitForever) == osOK) {
            // Start UART-overføring med DMA
            HAL_StatusTypeDef status = HAL_UART_Transmit_DMA(&huart2, (uint8_t *)receivedMsg->buffer, strlen(receivedMsg->buffer));

            // Hvis overføringen feiler, frigjør minnet umiddelbart
            if (status != HAL_OK) {
                osMemoryPoolFree(myPrintfPool, receivedMsg);
                continue;  // Gå til neste melding
            }

            // Vent til DMA-overføringen er fullført
            osThreadFlagsWait(0x01, osFlagsWaitAny, osWaitForever);

            // Frigjør minne tilbake til poolen etter overføring
            osMemoryPoolFree(myPrintfPool, receivedMsg);
        }
    }
}

// DMA-overføringskomplett callback
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        // Varsle MyPrintfServer-tråden om at overføringen er fullført
        osThreadFlagsSet(myPrintfServerHandle, 0x01);
    }
}

bool MyPrintfInit(void) {
    // Opprett en minnepool for å lagre MyPrintfMessage-strukturer
    myPrintfPool = osMemoryPoolNew(10, sizeof(MyPrintfMessage), NULL);
    if (myPrintfPool == NULL) {
        return false;
    }

    // Opprett meldingskø for å sende meldinger til MyPrintfServer
    myPrintfQueue = osMessageQueueNew(10, sizeof(MyPrintfMessage *), NULL);
    if (myPrintfQueue == NULL) {
        return false;
    }

    // Opprett MyPrintfServer-tråden
    osThreadAttr_t myPrintfServerAttr = {.name = "MyPrintfServer"};
    myPrintfServerHandle = osThreadNew(MyPrintfServer, NULL, &myPrintfServerAttr);
    if (myPrintfServerHandle == NULL) {
        return false;
    }

    return true;  // Sørg for at funksjonen returnerer true ved suksess
}

