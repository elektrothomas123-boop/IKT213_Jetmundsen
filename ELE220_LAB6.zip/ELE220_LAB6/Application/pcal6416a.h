#pragma once
#include "main.h"
int  PCAL_Init(I2C_HandleTypeDef *hi2c);                // autodetekterer 0x20/0x21
void PCAL_Config(uint8_t cfg0, uint8_t cfg1,            // 1=input, 0=output (0x06/0x07)
                 uint8_t pull_en0, uint8_t pull_en1,    // enable (0x46/0x47)
                 uint8_t pull_sel0, uint8_t pull_sel1,  // 1=pull-up (0x48/0x49)
                 uint8_t out_port_cfg);                 // 0=push-pull, 1=open-drain (0x4F)
HAL_StatusTypeDef PCAL_WriteOutputs(uint8_t out0, uint8_t out1); // 0x02/0x03
HAL_StatusTypeDef PCAL_ReadInputs(uint8_t *in0, uint8_t *in1);   // 0x00/0x01
