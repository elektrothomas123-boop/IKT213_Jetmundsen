/*
 * my_hardfault_handler.h
 *
 *  Created on: Sep 4, 2024
 *      Author: mkar1
 */

#ifndef MY_HARDFAULT_HANDLER_H
#define MY_HARDFAULT_HANDLER_H

#include "stm32f4xx_hal.h"  // Inkluder HAL-biblioteket for STM32

// Deklarasjon av HardFault-handleren
void MyHardFault_Handler(void);

#endif /* MY_HARDFAULT_HANDLER_H */
