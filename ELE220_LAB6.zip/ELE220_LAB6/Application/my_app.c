#include "my_app.h"
#include "lampControl.h"
#include "my_printf.h"
#include "stm32f4xx_hal.h"
#include "core_cm4.h"
#include "switchMonitor.h"    // Include SwitchMonitor functions
#include "pcal6416a.h"        // Header for I2C-ekspander

extern I2C_HandleTypeDef hi2c1;   // Deklarasjon av I2C-handle

void MyApp(void) {
    Myprintf("My_app function has been called.\r\n");

    Myprintf("Initializing SwitchMonitor...\r\n");
    if (!SwitchMonitorInit()) {
        Myprintf("SwitchMonitorInit failed!\r\n");
    } else {
        Myprintf("SwitchMonitorInit successful!\r\n");
    }

    Myprintf("Initializing LampControl...\r\n");
    if (!LampControlInit(2)) {
        Myprintf("LampControlInit failed!\r\n");
    } else {
        Myprintf("LampControlInit successful!\r\n");
    }

    Myprintf("Initializing PCAL6416A I2C expander...\r\n");
    if (PCAL_Init(&hi2c1) != 0) {
        Myprintf("PCAL_Init failed!\r\n");
        // Gå inn i feil-modus: stopp her
        for (;;);
    }
    Myprintf("PCAL_Init successful!\r\n");

    // *** Fyll inn riktige maskebiter for ditt oppsett ***
    uint8_t led_p0_mask = 0x0C;   // <–– bytt denne til de bitene som styrer D23/D24 på port0
    uint8_t led_p1_mask = 0x03;   // <–– bytt denne til de bitene som styrer D25/D26 på port1
    uint8_t btn_p0_mask = 0x30;   // <–– bytt denne til bitene som leser SW23/SW24 på port0
    uint8_t btn_p1_mask = 0x0C;   // <–– bytt denne til bitene som leser SW25/SW26 på port1

    // Konfigurer LED-bitene som output (0 = output), resten som input (1 = input)
    uint8_t cfg0 = 0xFF & ~led_p0_mask;
    uint8_t cfg1 = 0xFF & ~led_p1_mask;

    // Aktiver pull-ups for knappene
    PCAL_Config(
        cfg0,
        cfg1,
        btn_p0_mask, btn_p1_mask,    // pull enable bitmask
        btn_p0_mask, btn_p1_mask,    // pull select = pull-up bitmask
        0x00                        // output stage: 0 = push-pull
    );

    // Slå av alle LED-ene initialt (antatt aktiv-lav logikk)
    PCAL_WriteOutputs(0xFF, 0xFF);

    // Hovedloop: les knapper og styr LED-er
    for (;;) {
        uint8_t in0 = 0, in1 = 0;
        PCAL_ReadInputs(&in0, &in1);

        // Pull-up gir at trykket knapp = 0
        uint8_t pressed0 = (~in0) & btn_p0_mask;
        uint8_t pressed1 = (~in1) & btn_p1_mask;

        // For aktiv-lav LED: 0 = PÅ. Slå på LED hvis tilhørende knapp er trykket.
        uint8_t out0 = 0xFF & ~(pressed0 & led_p0_mask);
        uint8_t out1 = 0xFF & ~(pressed1 & led_p1_mask);

        PCAL_WriteOutputs(out0, out1);

        HAL_Delay(10);
    }
}

void vApplicationIdleHook(void) {
    __WFE();  // Wait For Event — lav-strømsmodus
}
