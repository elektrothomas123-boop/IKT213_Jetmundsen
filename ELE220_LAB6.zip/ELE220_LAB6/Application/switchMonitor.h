#ifndef __SWITCHMONITOR_H
#define __SWITCHMONITOR_H

#include <stdbool.h>
#include <stdint.h>
#include "cmsis_os.h"

#define EVENT_FLAG_SWITCH_1_PRESSED 0x01
#define EVENT_FLAG_SWITCH_2_PRESSED 0x02
#define EVENT_FLAG_SWITCH_3_PRESSED 0x04
#define EVENT_FLAG_SWITCH_4_PRESSED 0x08

bool SwitchMonitorInit(void);

#endif // __SWITCHMONITOR_H
