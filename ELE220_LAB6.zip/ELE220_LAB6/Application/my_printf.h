#ifndef MY_PRINTF_H_
#define MY_PRINTF_H_

void MyPrintf(const char *fmt, ...);

#endif /* MY_PRINTF_H_ */
