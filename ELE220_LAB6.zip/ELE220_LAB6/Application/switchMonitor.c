#include "switchMonitor.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "my_printf.h"
#include "pcal6416a.h"        // I2C ekspander
extern I2C_HandleTypeDef hi2c1; // I2C-håndtak

// Globale RTOS-objekter for hendelsesflagg
osEventFlagsId_t eventFlags;

typedef struct {
    uint8_t sw_mask_p0;   // mask for øvre del, port0
    uint8_t sw_mask_p1;   // mask for port1
    uint8_t prev_p0;      // tidligere verdi port0
    uint8_t prev_p1;      // tidligere verdi port1
} SwitchState;

void SwitchMonitor(void *arg) {
    SwitchState state = {
        .sw_mask_p0 = 0x30,  // EKSEMPEL: bitt 4 + 5 på port0 (SW23, SW24)
        .sw_mask_p1 = 0x0C,  // EKSEMPEL: bitt 2 + 3 på port1 (SW25, SW26)
        .prev_p0 = 0xFF,
        .prev_p1 = 0xFF
    };

    uint8_t in0 = 0, in1 = 0;

    for (;;) {
        PCAL_ReadInputs(&in0, &in1);

        uint8_t changed_p0 = (in0 ^ state.prev_p0) & state.sw_mask_p0;
        uint8_t changed_p1 = (in1 ^ state.prev_p1) & state.sw_mask_p1;

        if (changed_p0 | changed_p1) {
            // SW23
            if ((~in0 & state.sw_mask_p0) & (1u << 4)) {
                MyPrintf("SW23 pressed\r\n");
                osEventFlagsSet(eventFlags, EVENT_FLAG_SWITCH_1_PRESSED);
            } else if ((in0 & state.sw_mask_p0) & (1u << 4)) {
                MyPrintf("SW23 released\r\n");
            }
            // SW24
            if ((~in0 & state.sw_mask_p0) & (1u << 5)) {
                MyPrintf("SW24 pressed\r\n");
                osEventFlagsSet(eventFlags, EVENT_FLAG_SWITCH_2_PRESSED);
            } else if ((in0 & state.sw_mask_p0) & (1u << 5)) {
                MyPrintf("SW24 released\r\n");
            }
            // SW25
            if ((~in1 & state.sw_mask_p1) & (1u << 2)) {
                MyPrintf("SW25 pressed\r\n");
                osEventFlagsSet(eventFlags, EVENT_FLAG_SWITCH_3_PRESSED);
            } else if ((in1 & state.sw_mask_p1) & (1u << 2)) {
                MyPrintf("SW25 released\r\n");
            }
            // SW26
            if ((~in1 & state.sw_mask_p1) & (1u << 3)) {
                MyPrintf("SW26 pressed\r\n");
                osEventFlagsSet(eventFlags, EVENT_FLAG_SWITCH_4_PRESSED);
            } else if ((in1 & state.sw_mask_p1) & (1u << 3)) {
                MyPrintf("SW26 released\r\n");
            }
        }

        state.prev_p0 = in0;
        state.prev_p1 = in1;

        osDelay(50);  // Polling hvert 50 ms
    }
}

bool SwitchMonitorInit(void) {
    eventFlags = osEventFlagsNew(NULL);
    if (eventFlags == NULL) {
        MyPrintf("Failed to create event flags for SwitchMonitor!\r\n");
        return false;
    }

    // Init ekspanderen
    if (PCAL_Init(&hi2c1) != 0) {
        MyPrintf("PCAL_Init failed in SwitchMonitor!\r\n");
        return false;
    }

    // Konfigurer knappene som input + pull-ups
    uint8_t cfg0 = 0xFF;  // alle p0 som input
    uint8_t cfg1 = 0xFF;  // alle p1 som input
    uint8_t sw_p0_mask = 0x30;  // samme som ovenfor
    uint8_t sw_p1_mask = 0x0C;  // samme
    PCAL_Config(
        cfg0,
        cfg1,
        sw_p0_mask, sw_p1_mask,     // Pull-enable
        sw_p0_mask, sw_p1_mask,     // Pull-select (pull-up)
        0x00                        // Output stage konfigurert som push-pull
    );

    osThreadNew(SwitchMonitor, NULL, NULL);
    MyPrintf("SwitchMonitor initialized successfully.\r\n");
    return true;
}
