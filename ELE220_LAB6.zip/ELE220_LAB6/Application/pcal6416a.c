/*
 * pcal6416a.c
 *
 *  Created on: Oct 27, 2025
 *      Author: thomasjet
 */


#include "pcal6416a.h"

static I2C_HandleTypeDef *g_i2c;
static uint8_t g_addr7 = 0x20; // 7-bit (ADDR=0 → 0x20, ADDR=1 → 0x21)

static HAL_StatusTypeDef wr8(uint8_t reg, uint8_t val){
  return HAL_I2C_Mem_Write(g_i2c, g_addr7<<1, reg, I2C_MEMADD_SIZE_8BIT, &val, 1, 100);
}
static HAL_StatusTypeDef rd8(uint8_t reg, uint8_t *val){
  return HAL_I2C_Mem_Read(g_i2c, g_addr7<<1, reg, I2C_MEMADD_SIZE_8BIT, val, 1, 100);
}
static int probe(uint8_t a){
  uint8_t d;
  return (HAL_I2C_IsDeviceReady(g_i2c, a<<1, 1, 50)==HAL_OK) &&
         (HAL_I2C_Mem_Read(g_i2c, a<<1, 0x00, I2C_MEMADD_SIZE_8BIT, &d, 1, 50)==HAL_OK);
}

int PCAL_Init(I2C_HandleTypeDef *hi2c){
  g_i2c = hi2c;
  if (probe(0x20)) g_addr7 = 0x20;
  else if (probe(0x21)) g_addr7 = 0x21;
  else return -1;
  // Anbefalt: velg push-pull/OD pr. port først (0x4F). 0 = push-pull.
  (void)wr8(0x4F, 0x00);
  return 0;
}

void PCAL_Config(uint8_t cfg0, uint8_t cfg1,
                 uint8_t en0, uint8_t en1,
                 uint8_t sel0, uint8_t sel1,
                 uint8_t out_port_cfg)
{
  wr8(0x4F, out_port_cfg);          // Output port config (push-pull/OD)
  wr8(0x06, cfg0); wr8(0x07, cfg1); // Direction: 1=input, 0=output
  wr8(0x46, en0);  wr8(0x47, en1);  // Pull enable
  wr8(0x48, sel0); wr8(0x49, sel1); // 1 = pull-up
}

HAL_StatusTypeDef PCAL_WriteOutputs(uint8_t out0, uint8_t out1){
  HAL_StatusTypeDef s1 = wr8(0x02, out0);
  HAL_StatusTypeDef s2 = wr8(0x03, out1);
  return (s1==HAL_OK && s2==HAL_OK)? HAL_OK: HAL_ERROR;
}
HAL_StatusTypeDef PCAL_ReadInputs(uint8_t *in0, uint8_t *in1){
  HAL_StatusTypeDef s1 = rd8(0x00, in0);
  HAL_StatusTypeDef s2 = rd8(0x01, in1);
  return (s1==HAL_OK && s2==HAL_OK)? HAL_OK: HAL_ERROR;
}
