#include "lampControl.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "my_printf.h"
#include "gpio.h"
#include "switchMonitor.h"
#include "pcal6416a.h"           // <-- lagt til: header for ekspander

extern I2C_HandleTypeDef hi2c1;  // <-- lagt til: I2C-handle for PCAL

// Global semafor for å begrense antall blinkende LED-er
osSemaphoreId_t lampSemaphore;

// Definer hendelsesflagg (eksisterer globalt i SwitchMonitor)
extern osEventFlagsId_t eventFlags;

// Struktur for å holde LED-informasjon og event-flagg
typedef struct {
    // GPIO_TypeDef *gpioPort;    // Fjernet siden vi bruker ekspander
    // uint16_t gpioPin;          // Fjernet
    uint32_t delayMs;
    uint32_t eventFlag;
    char *lampName;
    bool isInverted;               // Indikerer om LED-en har invertert logikk
    uint8_t p0_bitmask;            // Nytt felt: maskebit i port0
    uint8_t p1_bitmask;            // Nytt felt: maskebit i port1
} LampControlArgs;

// Initialisering av strukturer for hver LED (legg inn riktige bitmasker)
static LampControlArgs lampArgs[4] = {
    {200, EVENT_FLAG_SWITCH_1_PRESSED, "LED1", true,  0x04, 0x00},  // eks: D23 på P0.2 → mask 0x04
    {400, EVENT_FLAG_SWITCH_2_PRESSED, "LED2", false, 0x08, 0x00},  // eks: D24 på P0.3 → mask 0x08
    {600, EVENT_FLAG_SWITCH_3_PRESSED, "LED3", true,  0x00, 0x01},  // eks: D25 på P1.0 → mask 0x01
    {800, EVENT_FLAG_SWITCH_4_PRESSED, "LED4", false, 0x00, 0x02}   // eks: D26 on P1.1 → mask 0x02
};

// Hjelpefunksjon for å sette tilstand på en LED via ekspander
static void SetLampStateExpander(const LampControlArgs *args, bool on)
{
    // Les nåværende utgangsverdier
    uint8_t out0 = 0xFF, out1 = 0xFF;
    // Først, sett alle LED-bitene som “av” (antatt aktiv-lav)
    // Her forenklet: vi benytter globale masker fra lampArgs
    // for bedre kontroll kunne vi lese tidligere verdi og modifisere.
    if (on) {
        if (args->p0_bitmask) {
            out0 &= ~(args->p0_bitmask);
        }
        if (args->p1_bitmask) {
            out1 &= ~(args->p1_bitmask);
        }
    } else {
        // Slå av: bit = 1 for av if aktiv-lav
        if (args->p0_bitmask) {
            out0 |= args->p0_bitmask;
        }
        if (args->p1_bitmask) {
            out1 |= args->p1_bitmask;
        }
    }
    PCAL_WriteOutputs(out0, out1);
}

void LampControl(void *arg) {
    LampControlArgs *args = (LampControlArgs *)arg;
    bool isBlinking = false;
    // Note: Vi bruker ekspander, så ikke HAL_GPIO_WritePin(...) etc.
    for (;;) {
        osEventFlagsWait(eventFlags, args->eventFlag, osFlagsWaitAny, osWaitForever);
        MyPrintf("Event flag detected for %s - controlled by corresponding switch.\r\n", args->lampName);

        if (!isBlinking) {
            if (osSemaphoreAcquire(lampSemaphore, 0) == osOK) {
                MyPrintf("%s started blinking at %lu ms interval.\r\n", args->lampName, args->delayMs);
                isBlinking = true;
                while (isBlinking) {
                    // Toggle
                    SetLampStateExpander(args, true);
                    osDelay(args->delayMs);
                    SetLampStateExpander(args, false);
                    osDelay(args->delayMs);

                    if (!(osEventFlagsWait(eventFlags, args->eventFlag, osFlagsWaitAny, 0) & osFlagsError)) {
                        isBlinking = false;
                        MyPrintf("%s stopped blinking.\r\n", args->lampName);
                    }
                }
                // Slå av LED etter blinking
                SetLampStateExpander(args, false);
                MyPrintf("%s is now OFF.\r\n", args->lampName);
                osSemaphoreRelease(lampSemaphore);
            } else {
                MyPrintf("Cannot start %s blinking, semaphore limit reached!\r\n", args->lampName);
            }
        } else {
            isBlinking = false;
            SetLampStateExpander(args, false);
            MyPrintf("%s has been stopped manually and is now OFF.\r\n", args->lampName);
        }
    }
}

bool LampControlInit(int maxLampsOn) {
    lampSemaphore = osSemaphoreNew(maxLampsOn, maxLampsOn, NULL);
    if (lampSemaphore == NULL) {
        MyPrintf("Error: Could not create semaphore!\r\n");
        return false;
    }

    // Før oppretting av tråder: init ekspander-utgangene til av
    PCAL_Init(&hi2c1);
    // Sett alle LED-bitene som output og slå dem av:
    {
        uint8_t all_led_p0_mask = lampArgs[0].p0_bitmask | lampArgs[1].p0_bitmask | lampArgs[2].p0_bitmask | lampArgs[3].p0_bitmask;
        uint8_t all_led_p1_mask = lampArgs[0].p1_bitmask | lampArgs[1].p1_bitmask | lampArgs[2].p1_bitmask | lampArgs[3].p1_bitmask;
        uint8_t cfg0 = 0xFF & ~all_led_p0_mask;
        uint8_t cfg1 = 0xFF & ~all_led_p1_mask;
        PCAL_Config(cfg0, cfg1,
                    0x00,   // pull-enable port0 (ingen knapper her for LED)
                    0x00,   // pull-enable port1
                    0x00,   // pull-select port0
                    0x00,   // pull-select port1
                    0x00); // push-pull
        PCAL_WriteOutputs(0xFF, 0xFF);  // Av alle LED
    }

    for (int i = 0; i < 4; i++) {
        osThreadId_t threadId = osThreadNew(LampControl, &lampArgs[i], NULL);
        if (threadId == NULL) {
            MyPrintf("Error: Failed to create thread for %s\r\n", lampArgs[i].lampName);
            return false;
        }
    }

    MyPrintf("LampControl initialized successfully!\r\n");
    return true;
}
